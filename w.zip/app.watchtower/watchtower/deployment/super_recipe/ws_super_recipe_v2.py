import json
import os
from collections import defaultdict
from json.decoder import JSONDecodeError
from pathlib import Path
from typing import Dict, Any, List
from urllib.parse import urlencode

import bottle
import natsort
from bottle import static_file
from pydantic.utils import deep_update

from ark.ark_server import ArkServer
from ark.config.constants import Email
from ark.log.logger import LoggerFactory
from ark.util import file_util
from ark.util import smtp_util
from ark.util.template_engine import TemplateEngine
from watchtower.config.constants import WatchTowerConstants
from watchtower.deployment.constants import APAC_ARTIFACTS, EMEA_ARTIFACTS

log = LoggerFactory.get_logger(__name__)


# ---------------------------------------------------------------------------
# Shared helpers (duplicated from ws_super_recipe to avoid importing that
# module at load time, which would register its bottle routes even when
# Nolio is not configured).
# ---------------------------------------------------------------------------

class VersionNotFoundError(Exception):
    def __init__(self, message: str):
        self.message = message


class PathNotFoundError(Exception):
    def __init__(self, message: str):
        self.message = message


def validate_path(data: Dict[str, Any]):
    """Check if artefact path is allowed."""
    KEY = "art_root"
    if KEY not in data:
        raise PathNotFoundError(f"Missing {KEY}")
    art_root = data[KEY]
    if not isinstance(art_root, str):
        raise PathNotFoundError(f"{KEY} is not a string: [{art_root}]")
    if art_root.upper() not in [APAC_ARTIFACTS.upper(), EMEA_ARTIFACTS.upper()]:
        raise PathNotFoundError(f"Unknown {KEY}: [{art_root}]")
    return art_root


def basic_recipe(data) -> Dict[str, Any]:
    """Basic Chuck recipe data."""
    return {
        "recipients": data["recipients"],
        "sender": data["sender"],
        "subject": data["subject"],
        "template": data["template"],
        "art_root": data["art_root"],
        "log_path": data["log_path"],
        "exclude_verify": data["exclude_verify"],
    }


def get_version(art_root: Path, artifact_data: Dict[str, Any]) -> str:
    name = artifact_data["artifact"]
    branch = artifact_data["branch"]
    suggested_version = artifact_data["version"]
    artifact_name = name + "~" + branch
    artifact_path = art_root / name

    version = None
    if str(suggested_version) == "latest":
        version_number = ""
        for p in artifact_path.glob(f"*{artifact_name}*.zip"):
            vn = p.stem.split("#")[1]
            if vn == natsort.natsorted([version_number, vn])[-1]:
                version_number = vn
                version = p.stem
    elif suggested_version:
        version = artifact_name + "#" + str(suggested_version)

    if not version:
        raise VersionNotFoundError(f"Artifact {artifact_name} not exist.")
    if not (artifact_path / (version + ".zip")).exists():
        raise VersionNotFoundError(f"Artifact {version} not exist.")
    return version


def create_actions_verify(env: str, artifact_info: Dict[str, Any]) -> List[Dict[str, Any]]:
    template_verify = artifact_info["verify"]
    env_to_ports = artifact_info["env_to_ports"]
    artefact_verify = []
    ports = env_to_ports.get(env, [])
    for port in ports:
        for template in template_verify:
            if template["assert"] != "CHECKPOINT":
                artefact_verify.append({
                    "command": "verify",
                    "url": template["url"].replace("{{port}}", str(port)),
                    "assert": template["assert"]
                })
    return artefact_verify


def create_checkpoints(artifact_info: Dict[str, Any]) -> List[Dict[str, Any]]:
    artefact_checkpoints = []
    for checkpoints in artifact_info["verify"]:
        if checkpoints["assert"] == "CHECKPOINT":
            artefact_checkpoints.append(checkpoints)
    return artefact_checkpoints


def read_config_files(release_path: Path, cr_number: str = None) -> List[Dict[str, Any]]:
    content = []
    if cr_number:
        pattern = f"*#{cr_number}.config"
    else:
        pattern = "*.config"
    for recipe_path in release_path.glob(pattern):
        try:
            data = json.loads(recipe_path.read_text())
            (lines, checksum) = file_util.md5(recipe_path)
            data["_file"] = {
                "name": recipe_path.name,
                "lines": lines,
                "checksum": checksum,
                "cr_number": recipe_path.name.split("#")[1].split(".")[0],
            }
            data["_error"] = False
            content.append(data)
        except JSONDecodeError:
            content.append({
                "_file": {"name": recipe_path.name},
                "_error": True,
            })
    return content


def get_model_paths(deployment_model):
    art_root = None
    file_name = None
    if deployment_model == "fiat_apac":
        art_root = APAC_ARTIFACTS
        file_name = "recipe_model.json"
    elif deployment_model == "fiat_emea":
        art_root = EMEA_ARTIFACTS
        file_name = "recipe_model.json"
    elif deployment_model == "comet_desktop":
        art_root = EMEA_ARTIFACTS
        file_name = "comet_desktop_recipe_model.json"
    elif deployment_model == "uat_fiat_emea":
        art_root = EMEA_ARTIFACTS
        file_name = "uat_recipe_model.json"
    elif deployment_model == "uat_fiat_apac":
        art_root = APAC_ARTIFACTS
        file_name = "uat_recipe_model.json"
    elif deployment_model == "uat_comet_desktop":
        art_root = EMEA_ARTIFACTS
        file_name = "uat_comet_desktop_recipe_model.json"

    model_file = None
    if art_root:
        model_file = Path(os.path.join(art_root, "Recipes", "chuck_cache", file_name))
    return model_file


def update_model(deployment_model, data: Dict[str, Any]):
    model_file = get_model_paths(deployment_model)
    if model_file:
        if model_file.exists():
            with open(model_file) as f:
                model = json.load(f)
        else:
            model = {}

        artifacts = model.get("artifacts", [])
        model = deep_update(model, data)
        for feature in ["release_date", "change_request_num"]:
            if feature in model:
                del model[feature]

        artifacts_model_map = {}
        for artifact in artifacts:
            artifacts_model_map[artifact["artifact"]] = artifact
        artifacts_data_map = {}
        for artifact in data["artifacts"]:
            artifacts_data_map[artifact["artifact"]] = artifact

        artifact_info = model["artifact_info"]
        artifact_names = list(artifact_info.keys())
        artifact_names.sort(key=str.lower)

        artifacts_new = []
        artifact_info_sorted = {}
        for artifact_name in artifact_names:
            artifact_info_sorted[artifact_name] = artifact_info[artifact_name]
            old = artifacts_model_map.get(artifact_name, {"artifact": artifact_name, "branch": ""})
            new = artifacts_data_map.get(artifact_name, {})
            old.update(new)
            old["version"] = "latest"
            old["envs"] = old["envs"] if old.get("envs") else list(artifact_info[artifact_name]["env_to_ports"].keys())
            artifacts_new.append(old)
        model["artifacts"] = artifacts_new
        model["artifact_info"] = artifact_info_sorted

        if not model_file.parent.exists():
            model_file.parent.mkdir()

        if deployment_model.startswith("uat_"):
            model["recipients"] = ""

        with open(model_file, "w") as f:
            json.dump(model, f, indent=4)


# ---------------------------------------------------------------------------
# V2 routes and logic (no Nolio integration)
# ---------------------------------------------------------------------------

@bottle.route("/deployment/super_recipe_v2", method="GET")
def get_recipe_v2_html():
    return static_file("ws_recipe_v2.html", root=os.path.dirname(__file__))


@bottle.route("/deployment/super_recipe_v2/recipe.js", method="GET")
def get_recipe_v2_js():
    return static_file("recipe_v2.js", root=os.path.dirname(__file__))


@bottle.route("/deployment/super_recipe_v2/model/<deployment_model>", method=["GET"])
def get_recipe_model_v2(deployment_model):
    """Read a recipe template saved in artefact path for each region."""
    model = {}
    model_file = get_model_paths(deployment_model)
    if model_file:
        if not os.path.exists(model_file):
            with open(model_file, "w") as f:
                json.dump({}, f)
        with open(model_file) as f:
            model = json.load(f)
        for feature in ["release_date", "change_request_num"]:
            if feature in model:
                del model[feature]

    bottle.response.content_type = "application/json"
    return json.dumps(model)


def create_artifact_v2(data: Dict[str, Any]) -> Dict[str, list]:
    """Return { env: [ { version, install, verify, checkpoints, name } ] }"""

    art_root = Path(data["art_root"])
    artifacts_info = data["artifact_info"]
    map_artefacts = defaultdict(list)

    for artifact_data in data["artifacts"]:
        name = artifact_data["artifact"]
        version = get_version(art_root, artifact_data)
        envs = artifact_data["envs"]

        artifact_info = artifacts_info[name]
        actions_install = {"command": "install", "versions": "{{versions.%s}}" % name}

        for env in envs:
            map_artefacts[env].append(
                {
                    "version": {name: version},
                    "install": actions_install,
                    "verify": create_actions_verify(env, artifact_info),
                    "checkpoints": create_checkpoints(artifact_info),
                    "name": name,
                }
            )

    return map_artefacts


def create_recipes_v2(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Create chuck recipes without Nolio — all artifacts become chuck recipes."""

    chuck_recipes = []
    artefacts_map = create_artifact_v2(data)
    env_to_hostnames = data["env_to_hostnames"]
    verify_pause = [{"command": "pause", "time": data["verify_pause"]}]

    for env, artefacts in artefacts_map.items():
        if env not in env_to_hostnames:
            log.warning(f"Skipping env '{env}' — no hostname mapping in env_to_hostnames")
            continue

        recipe = basic_recipe(data)
        recipe["env"] = env
        recipe["hostname"] = ",".join(env_to_hostnames[env])

        versions = {}
        install = []
        verify = []
        checkpoints = {}

        for artefact in artefacts:
            versions.update(artefact["version"])
            install.append(artefact["install"])
            verify.extend(artefact["verify"])
            artefact_checkpoints = artefact["checkpoints"]
            if artefact_checkpoints:
                checkpoints[artefact["name"]] = artefact_checkpoints

        recipe["versions"] = versions
        recipe["actions"] = install + verify_pause + verify
        recipe["checkpoints"] = checkpoints
        chuck_recipes.append(recipe)

    return chuck_recipes


def save_recipes_v2(data: Dict[str, Any], recipes: List[Dict[str, Any]]):
    """Save chuck recipes and main recipe JSON without Nolio fields."""

    change_request_num = data["change_request_num"]
    filename_tp = f"FIAT~{{0}}#{change_request_num}.config"

    art_root = Path(data["art_root"])
    release_date = data["release_date"]
    recipes_root = art_root / "Recipes" / release_date.replace("-", "")

    if not recipes_root.exists():
        recipes_root.mkdir()

    for recipe in recipes:
        filename = recipes_root / filename_tp.format(recipe["env"])
        with open(filename, "w") as f:
            json.dump(recipe, f, indent=4)

    # Save main recipe without Nolio-specific fields
    save_data = {k: v for k, v in data.items()
                 if k not in ("nolio_application", "nolio_project", "nolio_deployment_plan")}
    filename = recipes_root / f"recipe_main_{change_request_num}.json"
    with open(filename, "w") as f:
        json.dump(save_data, f, indent=4)


@bottle.route("/deployment/super_recipe_v2/create", method="POST")
def post_recipe_create_v2():
    """Create chuck recipes from super recipe — without Nolio integration."""

    bottle.response.content_type = "application/json"

    body: str = bottle.request.body.getvalue().decode('utf-8')
    data: Dict[str, Any] = json.loads(body)

    try:
        deployment_model = data.pop("deployment_model", None)
        validate_path(data)
        recipes = create_recipes_v2(data)
        save_recipes_v2(data, recipes)
        update_model(deployment_model, data)
    except (VersionNotFoundError, PathNotFoundError) as ex:
        return {
            "Success": False,
            "message": ex.message
        }

    region = None
    art_root: str = str(data["art_root"]).lower()
    if art_root == APAC_ARTIFACTS.lower():
        region = "apac"
    elif art_root == EMEA_ARTIFACTS.lower():
        region = "emea"

    return {
        "Success": True,
        "release_region": region,
        "release_date": data["release_date"]
    }


def _extract_apps(recipe: Dict[str, Any]) -> List[Dict[str, str]]:
    """Extract app name/branch/version from install actions in a recipe."""
    apps = []
    for action in recipe["actions"]:
        if action["command"] == "install":
            versions = action["versions"]
            app = versions[versions.find("{{") + 11: versions.find("}}")]
            branch, version = recipe["versions"][app].split("#")
            apps.append({"name": app, "branch": branch, "version": version})
    return apps


def _build_recipe_entry(recipe: Dict[str, Any]) -> Dict[str, Any]:
    """Build a single report entry from a parsed config file."""
    return {
        "env": recipe["env"],
        "file": recipe["_file"]["name"],
        "hostnames": str(recipe["hostname"]),
        "lines": recipe["_file"]["lines"],
        "checksum": recipe["_file"]["checksum"],
        "cr_number": recipe["_file"]["cr_number"],
        "apps": _extract_apps(recipe),
    }


def build_release_pipeline_url(
    project_url: str,
    cr_number: str,
    release_date: str,
    release_region: str,
    ref: str = "main",
) -> str:
    """Build a prepopulated GitLab 'Run Pipeline' URL for the release project.

    The pipeline expects YYYYMMDD folder name, Watchtower stores YYYY-MM-DD.
    """
    date_folder = release_date.replace("-", "")
    params = [
        ("ref", ref),
        ("var[CR_NUMBER]", cr_number),
        ("var[RELEASE_DATE]", date_folder),
        ("var[RELEASE_REGION]", release_region.lower()),
    ]
    return f"{project_url.rstrip('/')}/-/pipelines/new?{urlencode(params)}"


def _build_pipeline_urls_map(
    release_path: Path, release_region: str, release_date: str
) -> Dict[str, str]:
    """Return {cr_number: url} for every recipe_main_*.json in the release folder.

    Graceful degradation: returns {} if project URL is not configured or the
    release folder is missing — the Links column in the report still renders,
    just with empty cells.
    """
    try:
        cfg = ArkServer.AppContext.config
        project_url = cfg.get(WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL)
        ref = cfg.get(WatchTowerConstants.GITLAB_RELEASE_PIPELINE_REF) or "main"
    except AttributeError:
        return {}

    if not project_url or not release_path.exists():
        return {}

    urls: Dict[str, str] = {}
    for main_json in sorted(release_path.glob("recipe_main_*.json")):
        try:
            data = json.loads(main_json.read_text())
        except (JSONDecodeError, OSError):
            continue
        cr_number = data.get("change_request_num")
        if cr_number:
            urls[cr_number] = build_release_pipeline_url(
                project_url, cr_number, release_date, release_region, ref
            )
    return urls


def create_report_v2(release_path: Path, release_region: str, release_date: str,
                     cr_number: str = None, send_button: bool = True) -> str:
    """Generate deployment report without Nolio sections."""

    chuck_recipes = read_config_files(release_path, cr_number=cr_number)
    recipes = [_build_recipe_entry(r) for r in chuck_recipes if not r["_error"]]

    pipeline_urls = _build_pipeline_urls_map(release_path, release_region, release_date)
    for recipe in recipes:
        recipe["pipeline_url"] = pipeline_urls.get(recipe["cr_number"])

    template_dirs = [os.path.dirname(__file__)]
    rendered = TemplateEngine().render_template(
        template_dirs,
        "report_v2.jinja2",
        release_region=release_region,
        release_date=release_date,
        recipes=recipes,
        can_send_email=send_button,
    )

    return " ".join(rendered.split())


def send_email_v2(release_path: Path, release_date: str, release_region: str, cr_number: str):
    """Send deployment report email without Nolio."""

    report = create_report_v2(release_path, release_region, release_date,
                              cr_number=cr_number, send_button=False)
    smtp_sever = ArkServer.AppContext.config[Email.SMTP_HOST]
    main_recipe = json.loads((release_path / f"recipe_main_{cr_number}.json").read_text())
    smtp_util.send_message(smtp_sever=smtp_sever,
                           from_addr=main_recipe['sender'],
                           to_addrs=main_recipe['recipients'].split(","),
                           subject=f"Deployment plan - {release_region.upper()} - {release_date}",
                           body=report,
                           files=[])


@bottle.route("/deployment/super_recipe_v2/publish/<release_region>/<release_date>", method=["GET", "POST"])
def post_recipe_publish_v2(release_region, release_date) -> str:
    """
    GET: Display deployment report
    POST: Send deployment report email (no Nolio link creation)
    """
    release_path = None
    if release_region == "apac":
        release_path = APAC_ARTIFACTS
    elif release_region == "emea":
        release_path = EMEA_ARTIFACTS

    report = "Not found!"
    if release_path:
        release_path = Path(release_path) / "Recipes" / release_date.replace("-", "")
        if bottle.request.method == "POST":
            for main_recipe_path in release_path.glob("recipe_main_*.json"):
                main_recipe = json.loads(main_recipe_path.read_text())
                cr_number = main_recipe["change_request_num"]
                send_email_v2(release_path, release_date, release_region, cr_number)

        report = create_report_v2(release_path, release_region, release_date)

    bottle.response.content_type = "text/html; charset=utf-8"
    return report
