import json
import shutil
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import bottle

from ark.util import file_util
from ark.config.constants import Email
from ark.util import smtp_util
from watchtower.config.constants import WatchTowerConstants
from watchtower.deployment.super_recipe import ws_super_recipe_v2


RELEASE_REGION = "emea"
RELEASE_DATE = "2023-07-18"


@pytest.fixture
def md5_mock(monkeypatch):
    md5 = MagicMock(return_value=[20, 12345])
    monkeypatch.setattr(file_util, "md5", md5)
    return md5


@pytest.fixture
def release_path(tmp_path):
    data_test = Path(__file__).parent / "data_test"
    _release_path = tmp_path / "Recipes/20230718"
    _release_path.parent.mkdir()
    shutil.copytree(data_test, _release_path)
    return _release_path


def test_create_recipe_v2(tmp_path, monkeypatch):
    """v2 recipe creation: all artifacts become chuck recipes, no Nolio."""

    super_recipe_path = Path(__file__).parent / "data_test/recipe_main_CRTEST_3.json"
    art_root_path = tmp_path / "dfs-emea"
    art_root_path.mkdir()
    recipes_path = art_root_path / "Recipes"
    recipes_path.mkdir()

    monkeypatch.setattr(ws_super_recipe_v2, "EMEA_ARTIFACTS", str(art_root_path))

    # Create mock artifact zips
    app_mock_path = art_root_path / "App.Wasp"
    app_mock_path.mkdir()
    for version in range(1, 11):
        (app_mock_path / f"App.Wasp~GL.2023.03.03#{version}.zip").write_text("test")

    chuck_mock_path = art_root_path / "Chuck"
    chuck_mock_path.mkdir()
    (chuck_mock_path / "Chuck~GL.2024.01#3.zip").write_text("test")

    # Mock bottle request
    request = MagicMock()
    request.body = MagicMock()
    super_recipe = json.loads(super_recipe_path.read_text())
    super_recipe["art_root"] = str(art_root_path)
    request.body.getvalue = MagicMock(return_value=json.dumps(super_recipe).encode())
    monkeypatch.setattr(bottle, "response", MagicMock())
    monkeypatch.setattr(bottle, "request", request)

    result = ws_super_recipe_v2.post_recipe_create_v2()

    assert result == {"Success": True, "release_date": "2023-07-18", "release_region": "emea"}

    release_path = recipes_path / "20230718"
    created_files = {p.name for p in release_path.glob("*")}

    # EMEA-MOCK-A and LDN-MOCK have hostname mappings => configs created
    assert "FIAT~EMEA-MOCK-A#CRTEST_3.config" in created_files
    assert "FIAT~LDN-MOCK#CRTEST_3.config" in created_files
    assert "recipe_main_CRTEST_3.json" in created_files

    # Chuck env "EMEA-MOCK" has no hostname mapping => skipped with warning
    assert "FIAT~EMEA-MOCK#CRTEST_3.config" not in created_files

    # Verify config structure
    emea_config = json.loads((release_path / "FIAT~EMEA-MOCK-A#CRTEST_3.config").read_text())
    assert emea_config["env"] == "EMEA-MOCK-A"
    assert emea_config["hostname"] == "fiat-emeamock-a1,fiat-emeamock-a2"
    assert "App.Wasp" in emea_config["versions"]
    assert any(a["command"] == "install" for a in emea_config["actions"])
    assert any(a["command"] == "pause" for a in emea_config["actions"])
    assert any(a["command"] == "verify" for a in emea_config["actions"])

    # Main recipe must not contain Nolio fields
    main_recipe = json.loads((release_path / "recipe_main_CRTEST_3.json").read_text())
    assert "nolio_application" not in main_recipe
    assert "nolio_project" not in main_recipe
    assert "nolio_deployment_plan" not in main_recipe
    assert "_other_deployment_plan" not in main_recipe

    # Model cache updated
    chuck_cache_path = recipes_path / "chuck_cache/recipe_model.json"
    assert chuck_cache_path.exists()


def test_create_recipes_v2_all_chuck(monkeypatch):
    """v2 treats all artifacts as chuck recipes (no nolio split)."""

    data = {
        "art_root": "C:\\mock",
        "env_to_hostnames": {
            "ENV-A": ["host-a1"],
            "ENV-B": ["host-b1", "host-b2"],
        },
        "verify_pause": 30,
        "recipients": "test@test.com",
        "sender": "sender@test.com",
        "subject": "Test",
        "template": "verify.jinja2",
        "log_path": "//%s//logs",
        "exclude_verify": {},
        "artifact_info": {
            "MyApp": {
                "env_to_ports": {"ENV-A": [8080], "ENV-B": [8080]},
                "verify": [
                    {"assert": "VersionResult={{versions.MyApp}}", "url": "http://{{hostname}}:{{port}}/version"}
                ],
            }
        },
        "artifacts": [
            {"artifact": "MyApp", "version": "5", "branch": "main", "envs": ["ENV-A", "ENV-B"]},
        ],
    }

    def mock_get_version(art_root, artifact_data):
        return f"{artifact_data['artifact']}~{artifact_data['branch']}#{artifact_data['version']}"

    monkeypatch.setattr(ws_super_recipe_v2, "get_version", mock_get_version)

    recipes = ws_super_recipe_v2.create_recipes_v2(data)

    assert len(recipes) == 2
    envs = {r["env"] for r in recipes}
    assert envs == {"ENV-A", "ENV-B"}

    for recipe in recipes:
        assert "MyApp" in recipe["versions"]
        assert recipe["versions"]["MyApp"] == "MyApp~main#5"
        assert any(a["command"] == "install" for a in recipe["actions"])
        assert any(a["command"] == "pause" for a in recipe["actions"])
        assert any(a["command"] == "verify" for a in recipe["actions"])


def test_create_recipes_v2_skips_env_without_hostname(monkeypatch):
    """Envs without hostname mapping are skipped with a warning."""

    data = {
        "art_root": "C:\\mock",
        "env_to_hostnames": {
            "ENV-A": ["host-a1"],
            # ENV-B intentionally missing
        },
        "verify_pause": 30,
        "recipients": "test@test.com",
        "sender": "sender@test.com",
        "subject": "Test",
        "template": "verify.jinja2",
        "log_path": "//%s//logs",
        "exclude_verify": {},
        "artifact_info": {
            "MyApp": {
                "env_to_ports": {"ENV-A": [8080], "ENV-B": [8080]},
                "verify": [
                    {"assert": "VersionResult={{versions.MyApp}}", "url": "http://{{hostname}}:{{port}}/version"}
                ],
            }
        },
        "artifacts": [
            {"artifact": "MyApp", "version": "5", "branch": "main", "envs": ["ENV-A", "ENV-B"]},
        ],
    }

    def mock_get_version(art_root, artifact_data):
        return f"{artifact_data['artifact']}~{artifact_data['branch']}#{artifact_data['version']}"

    monkeypatch.setattr(ws_super_recipe_v2, "get_version", mock_get_version)

    recipes = ws_super_recipe_v2.create_recipes_v2(data)

    # Only ENV-A should have a recipe; ENV-B is skipped
    assert len(recipes) == 1
    assert recipes[0]["env"] == "ENV-A"


def test_save_recipes_v2_no_nolio_fields(tmp_path):
    """Saved main recipe has no Nolio fields."""

    art_root = tmp_path / "artifacts"
    art_root.mkdir()
    (art_root / "Recipes").mkdir()

    data = {
        "art_root": str(art_root),
        "release_date": "2024-01-15",
        "change_request_num": "CHG123",
        "nolio_application": "should-be-excluded",
        "nolio_project": "should-be-excluded",
        "nolio_deployment_plan": "should-be-excluded",
        "recipients": "test@test.com",
        "sender": "sender@test.com",
    }

    recipes = [
        {"env": "TEST-ENV", "hostname": "host1", "versions": {"App": "App~main#1"}, "actions": []}
    ]

    ws_super_recipe_v2.save_recipes_v2(data, recipes)

    release_path = art_root / "Recipes" / "20240115"
    main_recipe = json.loads((release_path / "recipe_main_CHG123.json").read_text())

    assert "nolio_application" not in main_recipe
    assert "nolio_project" not in main_recipe
    assert "nolio_deployment_plan" not in main_recipe
    assert main_recipe["change_request_num"] == "CHG123"
    assert main_recipe["recipients"] == "test@test.com"

    config = json.loads((release_path / "FIAT~TEST-ENV#CHG123.config").read_text())
    assert config["env"] == "TEST-ENV"


def test_create_report_v2(release_path, md5_mock):
    """v2 report does not contain Nolio sections."""

    report = ws_super_recipe_v2.create_report_v2(release_path, RELEASE_REGION, RELEASE_DATE)

    assert "Deployment plan" in report
    assert "Create Deployments Links" not in report
    assert "Nolio" not in report


def test_send_email_v2(monkeypatch, app_context, release_path):
    """v2 email sending works without Nolio."""

    app_context.config = {
        Email.SMTP_HOST: "mock@bar.com"
    }
    cr_number = "CRTEST"
    send_message = MagicMock(return_value=None)
    monkeypatch.setattr(smtp_util, "send_message", send_message)

    ws_super_recipe_v2.send_email_v2(release_path, RELEASE_DATE, RELEASE_REGION, cr_number)

    calls = send_message.call_args_list[0][1]
    assert calls["smtp_sever"] == "mock@bar.com"
    assert calls["subject"] == "Deployment plan - EMEA - 2023-07-18"
    assert "body" in calls


# ---------------------------------------------------------------------------
# GitLab release pipeline link
# ---------------------------------------------------------------------------


class TestBuildReleasePipelineUrl:
    def test_url_contains_all_variables(self):
        url = ws_super_recipe_v2.build_release_pipeline_url(
            project_url="https://app.gitlab.barcapint.com/barclays/comet/bvp-release",
            cr_number="CHG1010487246",
            release_date="2023-04-28",
            release_region="emea",
        )
        assert "/-/pipelines/new?" in url
        assert "ref=main" in url
        assert "CR_NUMBER" in url
        assert "CHG1010487246" in url
        assert "20230428" in url
        assert "emea" in url

    def test_date_strips_dashes(self):
        url = ws_super_recipe_v2.build_release_pipeline_url(
            project_url="https://gitlab.example.com/foo",
            cr_number="X",
            release_date="2023-04-28",
            release_region="emea",
        )
        assert "20230428" in url
        assert "2023-04-28" not in url

    def test_region_lowercased(self):
        url = ws_super_recipe_v2.build_release_pipeline_url(
            project_url="https://gitlab.example.com/foo",
            cr_number="X",
            release_date="2023-04-28",
            release_region="EMEA",
        )
        assert "emea" in url
        assert "EMEA" not in url

    def test_trailing_slash_stripped(self):
        url = ws_super_recipe_v2.build_release_pipeline_url(
            project_url="https://gitlab.example.com/foo/",
            cr_number="X",
            release_date="2023-04-28",
            release_region="emea",
        )
        assert "https://gitlab.example.com/foo/-/pipelines/new" in url
        assert "//-/pipelines" not in url

    def test_custom_ref_urlencoded(self):
        url = ws_super_recipe_v2.build_release_pipeline_url(
            project_url="https://gitlab.example.com/foo",
            cr_number="X",
            release_date="2023-04-28",
            release_region="emea",
            ref="release/2024",
        )
        assert "ref=release%2F2024" in url


class TestBuildPipelineUrlsMap:
    def test_empty_when_no_config(self, tmp_path, app_context):
        app_context.config = {}
        release_path = tmp_path / "Recipes" / "20230428"
        release_path.mkdir(parents=True)
        (release_path / "recipe_main_CHG123.json").write_text(
            json.dumps({"change_request_num": "CHG123"})
        )

        urls = ws_super_recipe_v2._build_pipeline_urls_map(release_path, "emea", "2023-04-28")

        assert urls == {}

    def test_empty_when_release_path_missing(self, tmp_path, app_context):
        app_context.config = {
            WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL: "https://gitlab.example.com/foo",
        }
        release_path = tmp_path / "Recipes" / "nonexistent"

        urls = ws_super_recipe_v2._build_pipeline_urls_map(release_path, "emea", "2023-04-28")

        assert urls == {}

    def test_builds_url_per_cr(self, tmp_path, app_context):
        app_context.config = {
            WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL:
                "https://app.gitlab.barcapint.com/barclays/comet/bvp-release",
            WatchTowerConstants.GITLAB_RELEASE_PIPELINE_REF: "main",
        }
        release_path = tmp_path / "Recipes" / "20230428"
        release_path.mkdir(parents=True)
        (release_path / "recipe_main_CHG123.json").write_text(
            json.dumps({"change_request_num": "CHG123"})
        )
        (release_path / "recipe_main_CHG456.json").write_text(
            json.dumps({"change_request_num": "CHG456"})
        )

        urls = ws_super_recipe_v2._build_pipeline_urls_map(release_path, "emea", "2023-04-28")

        assert len(urls) == 2
        assert set(urls.keys()) == {"CHG123", "CHG456"}
        for cr, url in urls.items():
            assert "/-/pipelines/new?" in url
            assert cr in url
            assert "20230428" in url
            assert "emea" in url

    def test_skips_recipe_main_without_cr(self, tmp_path, app_context):
        app_context.config = {
            WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL: "https://gitlab.example.com/foo",
        }
        release_path = tmp_path / "Recipes" / "20230428"
        release_path.mkdir(parents=True)
        (release_path / "recipe_main_broken.json").write_text(
            json.dumps({"some_other_field": "x"})
        )
        (release_path / "recipe_main_CHG1.json").write_text(
            json.dumps({"change_request_num": "CHG1"})
        )

        urls = ws_super_recipe_v2._build_pipeline_urls_map(release_path, "emea", "2023-04-28")

        assert len(urls) == 1
        assert "CHG1" in urls

    def test_skips_invalid_json(self, tmp_path, app_context):
        app_context.config = {
            WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL: "https://gitlab.example.com/foo",
        }
        release_path = tmp_path / "Recipes" / "20230428"
        release_path.mkdir(parents=True)
        (release_path / "recipe_main_bad.json").write_text("not valid json {{{")
        (release_path / "recipe_main_CHG1.json").write_text(
            json.dumps({"change_request_num": "CHG1"})
        )

        urls = ws_super_recipe_v2._build_pipeline_urls_map(release_path, "emea", "2023-04-28")

        assert len(urls) == 1
        assert "CHG1" in urls


class TestCreateReportV2PipelineLinks:
    def test_report_renders_link_column_when_config_present(
        self, release_path, md5_mock, app_context
    ):
        app_context.config = {
            WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL:
                "https://app.gitlab.barcapint.com/barclays/comet/bvp-release",
        }
        # Ensure there is at least one recipe_main_*.json in the release folder
        (release_path / "recipe_main_CRTEST.json").write_text(
            json.dumps({"change_request_num": "CRTEST"})
        )

        report = ws_super_recipe_v2.create_report_v2(release_path, RELEASE_REGION, RELEASE_DATE)

        # Links column header is always present
        assert "<strong>Links</strong>" in report
        # When config is present, link text appears on the first row
        assert "Run Release Pipeline" in report
        # CR number and URL path are embedded in the link
        assert "CRTEST" in report
        assert "/-/pipelines/new?" in report

    def test_report_shows_empty_link_column_when_config_missing(
        self, release_path, md5_mock, app_context
    ):
        app_context.config = {}  # No GitLab project URL

        report = ws_super_recipe_v2.create_report_v2(release_path, RELEASE_REGION, RELEASE_DATE)

        # Column header remains so the table layout stays consistent
        assert "<strong>Links</strong>" in report
        # But no link content is rendered
        assert "Run Release Pipeline" not in report
        assert "/-/pipelines/new?" not in report

    def test_no_separate_release_pipelines_section_above_tables(
        self, release_path, md5_mock, app_context
    ):
        """The old 'Release Pipelines' box above the tables must be gone."""
        app_context.config = {
            WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL:
                "https://app.gitlab.barcapint.com/barclays/comet/bvp-release",
        }
        (release_path / "recipe_main_CRTEST.json").write_text(
            json.dumps({"change_request_num": "CRTEST"})
        )

        report = ws_super_recipe_v2.create_report_v2(release_path, RELEASE_REGION, RELEASE_DATE)

        # The revised layout puts the link inside the per-recipe table, not as
        # a standalone "Release Pipelines" heading above everything.
        assert "Release Pipelines" not in report

    def test_link_appears_only_on_first_row_of_table(
        self, tmp_path, md5_mock, monkeypatch, app_context
    ):
        """For a recipe with multiple apps, 'Run Release Pipeline' must render
        exactly once per table (on the first <tr>), not once per app row."""
        app_context.config = {
            WatchTowerConstants.GITLAB_RELEASE_PROJECT_URL:
                "https://app.gitlab.barcapint.com/barclays/comet/bvp-release",
        }

        # Build a release folder with a single .config that has multiple apps
        release_path = tmp_path / "Recipes" / "20240115"
        release_path.mkdir(parents=True)

        config_data = {
            "env": "EMEA-MOCK-A",
            "hostname": "fiat-emeamock-a1",
            "versions": {
                "App.One": "App.One~main#1",
                "App.Two": "App.Two~main#2",
                "App.Three": "App.Three~main#3",
            },
            "actions": [
                {"command": "install", "versions": "{{versions.App.One}}"},
                {"command": "install", "versions": "{{versions.App.Two}}"},
                {"command": "install", "versions": "{{versions.App.Three}}"},
            ],
        }
        (release_path / "FIAT~EMEA-MOCK-A#CHG999.config").write_text(json.dumps(config_data))
        (release_path / "recipe_main_CHG999.json").write_text(
            json.dumps({"change_request_num": "CHG999"})
        )

        report = ws_super_recipe_v2.create_report_v2(release_path, "emea", "2024-01-15")

        # Exactly one link per table, not three
        assert report.count("Run Release Pipeline") == 1
        # All three apps rendered though
        assert "App.One" in report
        assert "App.Two" in report
        assert "App.Three" in report
